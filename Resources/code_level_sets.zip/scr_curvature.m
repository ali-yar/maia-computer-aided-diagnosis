
A = imread('monkey.png');
Ag = double(rgb2gray(A));

%contour
mask = zeros(size(Ag));
for i=1:100,
    mask(61:100,91:140)=ones;
    mask(161:200,41:200)=ones;
    mask(61:200,101:110)=ones;
end
f1 = figure;
imagesc(edge(mask))

%mask(121:220,121:220) = ones;
phi1 = bwdist(mask);
phi2 = bwdist(1-mask);
phi = (phi1-phi2)/2;
f2 = figure;
meshc(phi);
pause

%level set: phi_t + V*|Grad(phi)| = 0
dt = 1;
gxl = zeros(size(phi));
gxr = zeros(size(phi));
gyl = zeros(size(phi));
gyr = zeros(size(phi));
for i=1:12000
     [phix,phiy] = gradient(phi);
     [phixx,phixy] = gradient(phix);
     [phiyx,phiyy] = gradient(phiy);
     curvGrad = (phixx.*phiy.^2-2*phiy.*phix.*phixy+phiyy.*phix.^2)./(phix.^2+phiy.^2);
     phi = phi+dt*curvGrad;
     
     if ~mod(i,5)
         figure(f1)
         imagesc(edge(phi<0))
         pause(0.1)
         figure(f2)
         meshc(phi)
     end
end

