
A = imread('monkey.png');
Ag = double(rgb2gray(A));
Ag = Ag/max(Ag(:));
f3 = figure
imshow(Ag)
sob = [1 0 -1; 2 0 -2; 1 0 -1];
G1 = imfilter(Ag,sob); G2 = imfilter(Ag,sob');
G3 = imfilter(Ag,-sob); G4 = imfilter(Ag,-sob');
G = (abs(G1)+abs(G2)+abs(G3)+abs(G4));
F = 1./(1+255*G);
F = (F-min(F(:)))/(max(F(:))-min(F(:)));
F = -F;

%contour
mask = zeros(size(Ag));
for i=1:100,
%    mask(6:230,60:265)=ones;
    mask(120:130,145:155)=ones;
end
f1 = figure;
imagesc(edge(mask)+Ag)

%mask(121:220,121:220) = ones;
phi1 = bwdist(mask);
phi2 = bwdist(1-mask);
phi = (phi1-phi2)/2;
f2 = figure;
meshc(phi);
pause

%level set: phi_t + V*|Grad(phi)| = 0
%V = -ones(size(phi));
%V(200:end,:) = V(200:end,:)/10;
V = -F;
dt = 0.75;
c=1;
phiCurve(:,:,1) = phi;
gxl = zeros(size(phi));
gxr = zeros(size(phi));
gyl = zeros(size(phi));
gyr = zeros(size(phi));
for i=1:2000
    for j=2:size(phi,2)-1,
        gxl(:,j) = phi(:,j)-phi(:,j-1);
        gxr(:,j) = phi(:,j+1)-phi(:,j);
    end
    for j=2:size(phi,1)-1,
        gyl(j,:) = phi(j,:)-phi(j-1,:);
        gyr(j,:) = phi(j+1,:)-phi(j,:);
    end
    nabxr = max(0,gxl).^2+min(0,gxr).^2;
    nabyr = max(0,gyl).^2+min(0,gyr).^2;
    nabxl = max(0,gxr).^2+min(0,gxl).^2;
    nabyl = max(0,gyr).^2+min(0,gyl).^2;
    nabr = sqrt(nabxr+nabyr);
    nabl = sqrt(nabxl+nabyl);
    phi = phi-dt*(max(V,0).*nabr+min(V,0).*nabl);
    
    %curvature
    [phix,phiy] = gradient(phi);
    [phixx,phixy] = gradient(phix);
    [phiyx,phiyy] = gradient(phiy);
    curvGrad = (phixx.*phiy.^2-2*phiy.*phix.*phixy+phiyy.*phix.^2)./(phix.^2+phiy.^2);
    phi = phi+0.1*dt*curvGrad; %weight of the curvature

    %visualisation
%     phiCurve(:,:,c) = phi;
%     c = c+1;
%     subplot(1,2,1)
%     imagesc(phi)
%     subplot(1,2,2)
%     imagesc(abs(phi)<0.75)
    if ~mod(i,5)
        figure(f1)
        imagesc(edge(phi<0)+Ag)
        figure(f2)
        meshc(phi)
       drawnow
    end
    %re-init
    if ~mod(i,100)
        mask = phi<0;
        phi1 = bwdist(mask);
        phi2 = bwdist(1-mask);
        phi = (phi1-phi2)/2;
%        f2 = figure;
%        meshc(phi);
%        pause        
    end
    
end

%imagesc(edge(phi<0)+Ag)

% for i=1:size(phiCurve,3),
%     phiB(:,:,i) = abs(phiCurve(:,:,i)<1);
% end
% mesh(phiB)

