
A = imread('monkey.png');
Ag = double(rgb2gray(A));

%contour
mask = zeros(size(Ag));
for i=1:100,
    mask(60:200,60:265)=ones;
end
f1 = figure;
imagesc(edge(mask))

%mask(121:220,121:220) = ones;
phi1 = bwdist(mask);
phi2 = bwdist(1-mask);
phi = (phi1-phi2)/2;
f2 = figure;
meshc(phi);

%curve evolution
%V = -1;
V = -ones(size(phi));
V(150:end,:) = V(150:end,:)/20;
f3 = figure;
imagesc(V);
pause

dt = 0.75;
gxl = zeros(size(phi));
gxr = zeros(size(phi));
gyl = zeros(size(phi));
gyr = zeros(size(phi));
for i=1:120
    for j=2:size(phi,2)-1,
        gxl(:,j) = phi(:,j)-phi(:,j-1);
        gxr(:,j) = phi(:,j+1)-phi(:,j);
    end
    for j=2:size(phi,1)-1,
        gyl(j,:) = phi(j,:)-phi(j-1,:);
        gyr(j,:) = phi(j+1,:)-phi(j,:);
    end
    nabxr = max(0,gxl).^2+min(0,gxr).^2;
    nabyr = max(0,gyl).^2+min(0,gyr).^2;
    nabxl = max(0,gxr).^2+min(0,gxl).^2;
    nabyl = max(0,gyr).^2+min(0,gyl).^2;
    nabr = sqrt(nabxr+nabyr);
    nabl = sqrt(nabxl+nabyl);
    phi = phi-dt*(max(V,0).*nabr+min(V,0).*nabl);
     
    figure(f1)
    imagesc(edge(abs(phi<0.25)))
    figure(f2)
    meshc(phi)
    pause(0.1)
end

